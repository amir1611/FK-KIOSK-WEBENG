<?php
	session_start();
	include("../config/database.php");
	$id_user = $_SESSION['id_user'];
	
	$qry2="SELECT id_kiosk FROM `kiosk` WHERE `id_user`='$id_user'";
	$result=mysqli_query($con,$qry2);
	$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
	{
	$id_kioskview=$row['id_kiosk'];

	}
	
	
	
?>

<!DOCTYPE html>
<html lang="en">

<?php include 'head.php'; ?>
<title>Manage Menu</title>
<body class="w3-biru">

<?php include 'nav-1.php'; ?>



	<!-- Overlay effect when opening the side navigation on small screens -->
	<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="Close Sidemenu" id="myOverlay"></div>

	<!-- Page content -->
	<div class="w3-main" style="margin-left:250px;">

	<!-- sidebar -->
	<?php include 'nav-2.php'; ?>




		<div class="w3-padding-16"></div>

        <div class="w3-row">
            <div class="w3-container w3-content w3-xxlarge w3-cell" style="width: 90%;"> All Menus  </div>
            <div class="w3-container w3-padding-16 w3-cell" style="width: 5%;"><button class="w3-button w3-indigo w3-round-large"><i class="fas fa-qrcode"></i> Generate QR Code</button></div>
            <div class="w3-container w3-padding-16 w3-cell" style="width: 5%;"><a href="register_menu.php" class="w3-button w3-teal w3-round-large"><i class="fas fa-plus"></i> Add Menu</a></div>
        </div>



		<div class="w3-container">

			<!-- Page Container -->
			<div class="w3-container w3-content w3-white w3-card w3-padding-16 w3-round" style="max-width:1200px;">
				<!-- The Grid -->
				<div class="w3-row w3-white w3-padding">

					<div class="table-responsive">
						<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="text-align: center;">
							<thead>
								<tr>
									<th>#</th>
									<th>Menu Name</th>
									<th>Price</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>
							<?php 
								$bil = 0;
								$query_list = "SELECT * FROM `menu` WHERE `id_kiosk` = '$id_kioskview'";
								$result = mysqli_query($con, $query_list);
								while ($data = mysqli_fetch_array($result)) {
									$bil++;
							?>
								<tr>
									<td><?php echo $bil;?></td>
									<td><?php echo $data["menu_name"];?></td>
									<td>Rm <?php echo number_format((float)$data["price"], 2, '.', ''); ?></td>
									<td>
										<?php if($data["status"] == '1') {?>
										<span class="w3-badge w3-green">Available</span></td>
										<?php } ?>
										<?php if($data["status"] == '2') {?>
											<span class="w3-badge w3-red">Not Available</span></td>
										<?php } ?>


									<td>
									<?php $update_menu_A = "process/update_menu_A.php?id=" . $data['id_menu']; ?>
									<?php $update_menu_NA = "process/update_menu_NA.php?id=" . $data['id_menu']; ?>
									<?php $editLink = "edit_menu.php?id=" . $data['id_menu']; ?>
										<a href="<?php echo $update_menu_A; ?>" class="w3-button w3-green" style="border-radius: 20px;"><i class="fas fa-check"></i> Available</a>
										<a href="<?php echo $update_menu_NA; ?>" class="w3-button w3-red" style="border-radius: 20px;"><i class="fas fa-times"></i> Not Available</a>
										<a href="<?php echo $editLink; ?>" class="w3-button w3-deep-orange" style="border-radius: 20px;"><i class="fas fa-clipboard"></i> Edit</a>

									</td>

								</tr>
							<?php } ?>
							
						</table>
					</div>


					<!-- End Grid -->
				</div>

				<!-- End Page Container -->
			</div>




		</div>
		<!-- container end -->


		<footer class="w3-container w3-padding-1 w3-center" style="background: white;margin-top: 475px;">
			<p>&copy; 2023 FK KIOSK. All rights reserved.</p>
		</footer>


	</div>


	<script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
	<script src="../js/scripts.js"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
	<!--<script src="assets/demo/datatables-demo.js"></script>-->

	<script>
		$(document).ready(function() {


			$('#dataTable').DataTable({
				paging: true,

				searching: true
			});


		});
	</script>


	<script>
		var openInbox = document.getElementById("myBtn");
		openInbox.click();

		function w3_open() {
			document.getElementById("mySidebar").style.display = "block";
			document.getElementById("myOverlay").style.display = "block";
		}

		function w3_close() {
			document.getElementById("mySidebar").style.display = "none";
			document.getElementById("myOverlay").style.display = "none";
		}

		function myFunc(id) {
			var x = document.getElementById(id);
			if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-pale-red";
			} else {
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className =
					x.previousElementSibling.className.replace(" w3-red", "");
			}
		}
	</script>

</body>

</html>