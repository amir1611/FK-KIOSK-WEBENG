
<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<title>Register Kiosk</title>
<body class="w3-biru">


	<?php include 'nav-1.php'; ?>



	<!-- Overlay effect when opening the side navigation on small screens -->
	<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="Close Sidemenu" id="myOverlay"></div>

	<!-- Page content -->
	<div class="w3-main" style="margin-left:250px;">



		<?php include 'nav-2.php'; ?>



		<div class="w3-padding-32"></div>



		<div class="w3-container">

			<!-- Page Container -->
			<div class="w3-container w3-white w3-content w3-card w3-padding-16" style="max-width:400px; border-radius:20px;">
				<!-- The Grid -->
				<div class="w3-row w3-padding">

					<form action="" method="post">
						<div class="w3-padding">
							<div style="text-align: center;">
								<b class="w3-large">Kiosk Details</b>
							</div>

							<hr>

							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Kiosk Name <span style="color: red;">*</span></label>

								<input class="w3-input w3-border w3-round" type="text" name="name" value="" required>
							</div>

							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Enter Operating Hours <span style="color: red;">*</span></label>

								<input class="w3-input w3-border w3-round" type="text" name="phone" value="" required>
							</div>

							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Description <span style="color: red;">*</span></label>
								<input class="w3-input w3-border w3-round" type="text" name="phone" value="" required>
							</div>

							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Upload Image <span style="color: red;">*</span></label>

								<input type="file" name="image">
							</div>

							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Kiosk Status <span style="color: red;">*</span></label>
								<span class="w3-badge w3-large w3-green">Open</span>
								<select class="w3-input w3-border w3-round" name="role" required>
									<option value="open">Open</option>
									<option value="close">Close</option>
								</select>
							</div>

							<hr class="w3-clear">
							<input type="hidden" name="act" value="edit">
							<div style="text-align: center;">
								<button type="submit" class="btn-grad w3-button w3-blue w3-margin-bottom w3-round">UPDATE</button>
							</div>

						</div>
					</form>


					<!-- End Grid -->
				</div>

				<!-- End Page Container -->
			</div>




		</div>
		<!-- container end -->




		<footer class="w3-container w3-padding-1 w3-center" style="background: white;margin-top: 625px;">
			<p>&copy; 2023 FK KIOSK. All rights reserved.</p>
		</footer>


	</div>

	<script>
		var openInbox = document.getElementById("myBtn");
		openInbox.click();

		function w3_open() {
			document.getElementById("mySidebar").style.display = "block";
			document.getElementById("myOverlay").style.display = "block";
		}

		function w3_close() {
			document.getElementById("mySidebar").style.display = "none";
			document.getElementById("myOverlay").style.display = "none";
		}

		function myFunc(id) {
			var x = document.getElementById(id);
			if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-pale-red";
			} else {
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className =
					x.previousElementSibling.className.replace(" w3-red", "");
			}
		}
	</script>
</body>
</html>