<?php
	session_start();
	include("../config/database.php");
?>
<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<title>Manage Menu Dashboard</title>
<body class="w3-biru">
<?php include 'nav-1.php'; ?>

	<!-- Overlay effect when opening the side navigation on small screens -->
	<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="Close Sidemenu" id="myOverlay"></div>

	<!-- Page content -->
	<div class="w3-main" style="margin-left:250px;">

		<?php include 'nav-2.php'; ?>



		<div class="w3-padding-16"></div>

		<div class="w3-container w3-content w3-xxlarge " style="max-width:1200px;"> <b>Dashboard </b> </div>




		<div class="w3-container">

			<!-- Page Container -->
			<div class="w3-containerx w3-content  w3-padding-16 " style="max-width:1200px;">
				<!-- The Grid -->
				<div class="w3-row ">

					<div class="w3-col m3 w3-container w3-padding">
						<div class="w3-card w3-border w3-white w3-center w3-round-xlarge w3-margin w3-padding w3-padding-16 glow-animation">
							<div class="w3-row"><i class="fa fa-fw fa-book-reader fa-2x w3-left w3-text-blue"></i></div>
							<h1><b>4</b></h1>
							Menus<br>
						</div>
					</div>


					<div class="w3-col m3 w3-container w3-padding">
						<div class="w3-card w3-border w3-white w3-center w3-round-xlarge w3-margin w3-padding w3-padding-16 glow-animation">
							<div class="w3-row"><i class="fa fa-fw fa-check fa-2x w3-left w3-text-blue"></i></div>
							<h1><b>20</b></h1>
							Orders<br>
						</div>
					</div>

					<div class="w3-col m3 w3-container w3-padding">
						<div class="w3-card w3-border w3-white w3-center w3-round-xlarge w3-margin w3-padding w3-padding-16 glow-animation">
							<div class="w3-row"><i class="fa fa-fw fa-chart-pie fa-2x w3-left w3-text-blue"></i></div>
							<h1><b>20</b></h1>
							Total Sales<br>
						</div>
					</div>

					<div class="w3-col m3 w3-container w3-padding">
						<div class="w3-card w3-border w3-white w3-center w3-round-xlarge w3-margin w3-padding w3-padding-16 glow-animation">
							<div class="w3-row"><i class="fa fa-fw fa-user-check fa-2x w3-left w3-text-blue"></i></div>
							<h1><span class="w3-text-green">Open</span></h1>
							Current Kiosk Status<br>
						</div>
					</div>



					<!-- End Grid -->
				</div>



				<!-- End Page Container -->
			</div>





		</div>
		<!-- container end -->


   
		<div id="myChart" style="height: 250px; max-width: 1200px; margin-bottom: -50px;"></div>









		<footer class="w3-container w3-padding-1 w3-center" style="background: white;margin-top: 472px;">
			<p>&copy; 2023 FK KIOSK. All rights reserved.</p>
		</footer>


	</div>

	<script>
		var food1 = 20;
		var food2 = 20;
		var food3 = 20;
		var food4 = 20;

		var options = {
			chart: {
				type: 'donut',
				height: 250, // Set the height of the chart
				background: 'transparent', // Set the background color
			},
			labels: ['Menu 1', 'Menu 2', 'Menu 3', 'Menu 4'],
			series: [food1, food2, food3, food4],
			colors: ['#3498db', '#2ecc71', '#e74c3c', '#f1c40f'],
			plotOptions: {
				pie: {
					donut: {
						size: '50%', // Set the size of the donut
					}
				}
			}
		};

		var chart = new ApexCharts(document.querySelector("#myChart"), options);
		chart.render();

		function w3_open() {
			document.getElementById("mySidebar").style.display = "block";
			document.getElementById("myOverlay").style.display = "block";
		}

		function w3_close() {
			document.getElementById("mySidebar").style.display = "none";
			document.getElementById("myOverlay").style.display = "none";
		}

		function myFunc(id) {
			var x = document.getElementById(id);
			if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-pale-red";
			} else {
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className =
					x.previousElementSibling.className.replace(" w3-red", "");
			}
		}
	</script>
</body>
</html>