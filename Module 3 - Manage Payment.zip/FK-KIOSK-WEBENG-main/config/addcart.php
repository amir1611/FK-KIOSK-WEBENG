<?php
session_start();

include("database.php");
if (!verifyUser($con)) {
    // Handle unauthorized access if needed
    echo "Unauthorized access";
    return;
}
    $id_user = $_SESSION["id_user"];
    $menuId = $_POST["id_menu"];
	$kiosk = $_POST["kiosk"];
	$price = $_POST["price"];
	$qty = $_POST["qty"];
	
	$totalPrice = $qty * $price;
	

    $SQL_insert = "INSERT INTO `cart`(`id_user`, `id_menu`, `id_kiosk`, `qty`, `price`) VALUES ('$id_user', '$menuId', '$kiosk', '$qty', '$totalPrice')";
    $result = mysqli_query($con, $SQL_insert);

    if ($result) {
        echo "Item added to cart successfully";
		header("Location:../manageAccount/user/menu_page.php?id=$kiosk");

    } else {
        echo "Error adding item to cart";
    }

?>
