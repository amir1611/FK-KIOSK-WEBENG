-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2024 at 06:04 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fkkiosk`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `email`) VALUES
(1, 'admin', '1234', 'admin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id_cart` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_menu` int(11) NOT NULL,
  `id_kiosk` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` double NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id_cart`, `id_user`, `id_menu`, `id_kiosk`, `qty`, `price`, `date_added`) VALUES
(27, 2, 7, 5, 2, 3, '2024-01-21 16:53:44'),
(28, 2, 6, 5, 1, 9.2, '2024-01-21 16:53:48'),
(29, 2, 8, 5, 3, 16.5, '2024-01-21 16:53:49');

-- --------------------------------------------------------

--
-- Table structure for table `kiosk`
--

CREATE TABLE `kiosk` (
  `id_kiosk` int(11) NOT NULL,
  `id_user` int(11) NOT NULL DEFAULT 0,
  `kiosk_name` varchar(500) NOT NULL DEFAULT '0',
  `operating_hours` varchar(500) NOT NULL DEFAULT '0',
  `kiosk_information` varchar(500) NOT NULL DEFAULT '0',
  `status` varchar(50) DEFAULT '0',
  `kiosk_img_dir` longtext NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kiosk`
--

INSERT INTO `kiosk` (`id_kiosk`, `id_user`, `kiosk_name`, `operating_hours`, `kiosk_information`, `status`, `kiosk_img_dir`, `updated_at`) VALUES
(4, 1, 'FKOM KIOSK', '9.00 a.m - 10.00 p.m', 'FKOM KIOSK', 'open', 'none', '2024-01-19 09:50:10'),
(5, 7, 'SALLEH KIOSK', '9.00 a.m - 10.00 p.m', 'SALLEH KIOSK', 'open', 'none', '2024-01-19 09:50:32'),
(6, 8, 'HANOM KIOSK', '7.30 Am - 2.00 Pm', 'HANOM KIOSK', 'open', 'none', '2024-01-19 09:50:50');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL,
  `id_kiosk` int(11) NOT NULL DEFAULT 0,
  `menu_name` varchar(500) DEFAULT '0',
  `price` float NOT NULL DEFAULT 0,
  `status` int(11) DEFAULT 0,
  `image_dir` longtext NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id_menu`, `id_kiosk`, `menu_name`, `price`, `status`, `image_dir`, `updated_at`) VALUES
(3, 4, 'Nasi Goreng Kampung', 8.5, 1, 'nasi_goreng_kampung.jpeg', '2024-01-15 13:25:11'),
(4, 4, 'Bakso', 5, 1, 'ilustrasi-bakso_43.jpeg', '2024-01-18 13:49:44'),
(5, 4, 'Mee Goreng Daging', 6.5, 1, 'Mee_Goreng_Daging.jpg', '2024-01-16 04:50:10'),
(6, 5, 'Maggi Goreng', 9.2, 2, 'Maggi-Goreng.jpg', '2024-01-15 13:28:54'),
(7, 5, 'Teh o ais', 1.5, 1, 'teh-o-ais.jpg', '2024-01-15 13:28:14'),
(8, 5, 'Sandwich', 5.5, 1, 'sandwich.jpg', '2024-01-15 06:32:37'),
(9, 6, 'Asam Pedas Ikan', 6.5, 1, 'asam-pedas-ikan-selar-resipi-foto-utama.jpg', '2024-01-18 12:50:36'),
(10, 6, 'Char Kuey Teow Kerang', 6.5, 1, 'maxresdefault.jpg', '2024-01-18 13:07:42'),
(11, 4, 'Kari Kambing', 8, 1, '7921578d01104653830e90f4e8e7f499.jpg', '2024-01-18 13:33:25');

-- --------------------------------------------------------

--
-- Table structure for table `menu_stat`
--

CREATE TABLE `menu_stat` (
  `id` int(11) NOT NULL,
  `details` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_stat`
--

INSERT INTO `menu_stat` (`id`, `details`) VALUES
(1, 'Available'),
(2, 'Not Available');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id_order` int(11) NOT NULL,
  `no_order` int(11) NOT NULL,
  `id_menu` int(11) NOT NULL,
  `id_kiosk` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL,
  `status` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id_order`, `no_order`, `id_menu`, `id_kiosk`, `id_user`, `quantity`, `price`, `status`, `updated_at`) VALUES
(241, 1742, 7, 5, 2, 2, 3, 1, '2024-01-21 16:55:09'),
(242, 1742, 6, 5, 2, 1, 9.2, 1, '2024-01-21 16:55:09'),
(243, 1742, 8, 5, 2, 3, 16.5, 2, '2024-01-21 16:56:27');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id_payment` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `id_menu` int(11) NOT NULL,
  `id_order` int(11) NOT NULL,
  `id_membership` int(11) NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `payment_amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `details` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `details`) VALUES
(1, 'User'),
(2, 'Vendor');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `role` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `document` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `role`, `name`, `phone`, `email`, `password`, `document`, `status`) VALUES
(1, '2', 'Muhammad Hanif', '0198888888', 'vendor@gmail.com', '1234', 'user.pdf', 'Approved'),
(2, '1', 'Nur Atirah', '0198888888', 'user@gmail.com', '1234', 'vendor.pdf', 'Approved'),
(7, '2', 'Ahmad Ali', '0109533882', 'ali@gmail.com', '1234', 'BCS2243 Project Instruction_SEM I_202324.pdf', 'Approved'),
(8, 'vendor', 'test2', '0123456789', 'test2@gmail.com', '1234', '', 'Approved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id_cart`);

--
-- Indexes for table `kiosk`
--
ALTER TABLE `kiosk`
  ADD PRIMARY KEY (`id_kiosk`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_menu`);

--
-- Indexes for table `menu_stat`
--
ALTER TABLE `menu_stat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id_order`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id_payment`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id_cart` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `kiosk`
--
ALTER TABLE `kiosk`
  MODIFY `id_kiosk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `menu_stat`
--
ALTER TABLE `menu_stat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=244;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id_payment` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
