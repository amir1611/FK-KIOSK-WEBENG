<?php
	session_start();
	include("../config/database.php");
	$id_user = $_SESSION['id_user'];
	$act = (isset($_POST['act'])) ? trim($_POST['act']) : '';
	$id_menu=$_GET['id'];
	
	$qry2="SELECT * FROM `menu` WHERE `id_menu`='$id_menu'";
	$result=mysqli_query($con,$qry2);
	$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
	{
	$menu_name=$row['menu_name'];
	$price=$row['price'];
	$image_dir=$row['image_dir'];
	$status=$row['status'];
	}
	
	
	if ($act == 'submit') {
		
		$uploadDir = 'images/';
		$fileName = $_FILES['image']['name'];
		$tmpName  = $_FILES['image']['tmp_name'];
		$fileSize = $_FILES['image']['size'];
		$fileType = $_FILES['image']['type'];
		$filePath = $uploadDir . $fileName;
		$result = move_uploaded_file($tmpName, $filePath);
		if(!get_magic_quotes_gpc())
		{
				$fileName = addslashes($fileName);
				$filePath = addslashes($filePath);
		}
		
		$menu_name = (isset($_POST['menu_name'])) ? trim($_POST['menu_name']) : '';
		$price = (isset($_POST['price'])) ? trim($_POST['price']) : '';
		$status = (isset($_POST['status'])) ? trim($_POST['status']) : '';
		$timestamp = date("Y-m-d H:i:s");
		$query = "UPDATE `menu` SET `menu_name`='$menu_name',`price`='$price',`status`='$status',`image_dir`='$fileName',`updated_at`='$timestamp' WHERE `id_menu`='$id_menu;'";

		$result = mysqli_query($con, $query) or die("Error in query: " . $query . "<br />" . mysqli_error($con));
		header("Location: manage_menu.php");
	}
	
	
	
	
	
?>
<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<title>Edit Menu</title>
<style>
        #imagePreview {
            max-width: 100%;
            max-height: 200px;
            margin-top: 10px;
        }
    </style>
<body class="w3-biru">


<?php include 'nav-1.php'; ?>



	<!-- Overlay effect when opening the side navigation on small screens -->
	<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="Close Sidemenu" id="myOverlay"></div>

	<!-- Page content -->
	<div class="w3-main" style="margin-left:250px;">



		<?php include 'nav-2.php'; ?>



		<div class="w3-padding-32"></div>



		<div class="w3-container">

			<!-- Page Container -->
			<div class="w3-container w3-white w3-content w3-card w3-padding-16" style="max-width:400px; border-radius:20px;">
				<!-- The Grid -->
				<div class="w3-row w3-padding">

					<form action="" method="post" enctype="multipart/form-data">
						<div class="w3-padding">
							<div style="text-align: center;">
								<b class="w3-large">Menu Details</b>
							</div>

							<hr>

							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Menu Name <span style="color: red;">*</span></label>

								<input class="w3-input w3-border w3-round" type="text" name="menu_name" value="<?php echo $menu_name; ?>" required>
								<input type="hidden" name="id_menu" value="<?php echo $id_menu; ?>">
							</div>

							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Price <span style="color: red;">*</span></label>

								<input class="w3-input w3-border w3-round" type="number" step="0.01" name="price" value="<?php echo $price; ?>" required>
							</div>
							
							
							
							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Food Status <span style="color: red;">*</span></label>
								<select class="w3-input w3-border w3-round" name="status" required>
					<option value="" disabled >Choose Food Status</option>
						<?php
							
							$val = $status?:'';
							$sql = "SELECT * FROM `menu_stat` ORDER BY `id`";
							$res = mysqli_query($con,$sql);
							while ($row1 = mysqli_fetch_array($res)) {
								$selected = ($val == $row1['id'] ? 'selected="selected"' : '');
								echo '<option value ="' . $row1['id'] . '" '. $selected .'>' . $row1['details'] . '</option>';
							}
							
							
							
						?>
					</select>
								
								
								
							</div>





















							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Upload Image <span style="color: red;">*</span></label>

								<input type="file" name="image" accept="image/*" onchange="previewImage(event)" required>
								<div id="imagePreview"></div>
							</div>

							<script>
								// Trigger the previewImage function when the page loads
								window.onload = function () {
									// Pass an empty event object to simulate the onchange event
									previewImage({ target: document.querySelector('input[name="image"]') });
								};

								function previewImage(event) {
									var input = event.target;
									var preview = document.getElementById('imagePreview');

									// Clear previous preview
									preview.innerHTML = '';

									if (input.files && input.files[0]) {
										var reader = new FileReader();

										reader.onload = function (e) {
											var image = document.createElement('img');
											image.src = e.target.result;
											image.style.maxWidth = '100%';
											image.style.maxHeight = '200px';
											preview.appendChild(image);
										};

										reader.readAsDataURL(input.files[0]);
									} else {
										// If no file is selected, display the default image
										var defaultImage = document.createElement('img');
										defaultImage.src = './images/<?php echo htmlspecialchars($image_dir, ENT_QUOTES, 'UTF-8'); ?>';
										defaultImage.style.maxWidth = '100%';
										defaultImage.style.maxHeight = '200px';
										preview.appendChild(defaultImage);
									}
								}
							</script>


							<hr class="w3-clear">
							<input type="hidden" name="act" value="submit">
							<div style="text-align: center;">
							<input type="hidden" name="act" value="submit">
								<button type="submit" class="btn-grad w3-button w3-blue w3-margin-bottom w3-round">UPDATE</button>
							</div>

						</div>
					</form>


					<!-- End Grid -->
				</div>

				<!-- End Page Container -->
			</div>




		</div>
		<!-- container end -->




		<footer class="w3-container w3-padding-1 w3-center" style="background: white;margin-top: 625px;">
			<p>&copy; 2023 FK KIOSK. All rights reserved.</p>
		</footer>


	</div>

	<script>
		var openInbox = document.getElementById("myBtn");
		openInbox.click();

		function w3_open() {
			document.getElementById("mySidebar").style.display = "block";
			document.getElementById("myOverlay").style.display = "block";
		}

		function w3_close() {
			document.getElementById("mySidebar").style.display = "none";
			document.getElementById("myOverlay").style.display = "none";
		}

		function myFunc(id) {
			var x = document.getElementById(id);
			if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-pale-red";
			} else {
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className =
					x.previousElementSibling.className.replace(" w3-red", "");
			}
		}
	</script>
</body>
</html>