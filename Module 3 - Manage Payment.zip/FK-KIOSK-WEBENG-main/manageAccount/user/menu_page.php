<?PHP
session_start();

include("../../config/database.php");
if (!verifyUser($con)) {
	header("Location: index.php");
	return false;
}

$id_kiosk =$_GET['id'];

$id_user	= $_SESSION["id_user"];
$act 		= (isset($_REQUEST['act'])) ? trim($_REQUEST['act']) : '';

$name 		= (isset($_POST['name'])) ? trim($_POST['name']) : '';
$email		= (isset($_POST['email'])) ? trim($_POST['email']) : '';
$phone		= (isset($_POST['phone'])) ? trim($_POST['phone']) : '';
$password	= (isset($_POST['password'])) ? trim($_POST['password']) : '';

$success = "";

if ($act == "edit") {
	$SQL_update = " 
	UPDATE
		`user`
	SET
		`name` = '$name',
		`email` = '$email',
		`phone` = '$phone',
		`password` = '$password'
	WHERE
		`id_user`='$id_user' 
		";

	$result = mysqli_query($con, $SQL_update);

	$success = "Successfully Update";
	//print "<script>self.location='a-profile.php';</script>";
}

$SQL_list = "SELECT * FROM `user` WHERE `id_user` = '$id_user' ";
$result = mysqli_query($con, $SQL_list);
$data	= mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>FKKIOSK</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../../w3.css">
	<link href='https://fonts.googleapis.com/css?family=RobotoDraft' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
	<style>
		a {
			text-decoration: none;
		}

		html,
		body,
		h1,
		h2,
		h3,
		h4,
		h5 {
			font-family: "RobotoDraft", "Roboto", sans-serif
		}

		.w3-bar-block .w3-bar-item {
			padding: 16px
		}

		.w3-biru {
			background-color: #f6f9ff;
		}

		         
		         
		.btn-grad {
            background-image: linear-gradient(to right, #D38312 0%, #A83279  51%, #D38312  100%);
            margin: 0px;
            padding: 15px 45px;
            text-align: center;
            text-transform: uppercase;
            transition: 0.5s;
            background-size: 200% auto;
            color: white;            
            box-shadow: 0 0 20px #eee;
            border-radius: 10px;
            align-self: center;;
          }

          .btn-grad:hover {
            background-position: right center; /* change the direction of the change here */
            color: #fff;
            text-decoration: none;
          }
        
        /* Include the CSS code here */
        input[type="number"] {
            width: 38%;
            padding: 10px;
            margin: 5px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            background-color: #f8f8f8;
            font-size: 16px;
            color: #333;
        }
         

	</style>
</head>

<body class="w3-biru">

	<!--- Toast Notification -->
	<?PHP
	if ($success) {
		Notify("success", $success, "profile.php");
	}
	?>

	<?php include 'nav-1.php';  ?>



	<!-- Overlay effect when opening the side navigation on small screens -->
	<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="Close Sidemenu" id="myOverlay"></div>

	<!-- Page content -->
	<div class="w3-main" style="margin-left:250px;">



		<div class="w3-white w3-bar w3-card ">


			
			

			<div class="w3-large w3-buttonx w3-bar-item w3-right w3-white w3-dropdown-hover">
				<button class="w3-button"><i class="fa fa-fw fa-user-circle"></i> User <i class="fa fa-fw fa-chevron-down w3-small"></i></button>
				<div class="w3-dropdown-content w3-bar-block w3-card-4" style="min-width: 54px;">
					<a href="profile.php" class="w3-bar-item w3-button"><i class="fa fa-fw fa-user-cog "></i> Profile</a>
					<a href="../../config/userlogout.php" class="w3-bar-item w3-button"><i class="fa fa-fw fa-sign-out-alt "></i> Logout</a>
				</div>
			</div>
			<div class="w3-large w3-buttonx w3-bar-item w3-right w3-white" id="cartContainer">
			<a href="view_cart.php"><button class="w3-button"><i class="fa fa-shopping-cart"></i> Cart <span id="cartCount"></span></button></a>
		</div>

		</div>

		<div class="w3-padding-32"></div>

		<div class="w3-container">

			<!-- Page Container -->
			<div class="w3-container w3-white w3-content w3-card w3-padding-16" style="max-width:100%; max-height: 100%; border-radius:20px; ">
				<!-- The Grid -->
				
				<div class="w3-container w3-center" >

					<?php
						$menu_sql = "SELECT * FROM `menu` where id_kiosk='$id_kiosk' ";
						$result = mysqli_query($con, $menu_sql);
						while ($data = mysqli_fetch_array($result)) {
							# code...
						
					?>
					<center>
					<div class="w3-third w3-container w3-padding-16" id="contact" >
						<div class="w3-white w3-card-4 w3-r" style="max-width:400px;">
							<img src="../../manageMenu/images/<?php echo $data['image_dir']; ?>" style="width: 100%; height: 250px;" alt="nasi_goreng_kampung">
							<div class="w3-padding-16 w3-container w3-center">
								<p><?php echo $data['menu_name']; ?></p>
								<p>Rm <?php echo number_format((float)$data["price"], 2, '.', ''); ?></p>
								<p>
									<?php if($data["status"] == 'available') {?>
									<span class="w3-badge w3-green">Available</span></td>
									<?php } ?>
									<?php if($data["status"] == 'unavailable') {?>
										<span class="w3-badge w3-red">Unavailable</span></td>
									<?php } ?>
								</p>
								<form action="../../config/addcart.php" method="POST"   enctype="multipart/form-data">
								<input type="number" name="qty" placeholder="Enter Quantity">
								<input type="hidden" name="price" value="<?php echo $data['price']; ?>">
								<input type="hidden" name="kiosk" value="<?php echo $data['id_kiosk']; ?>">
								<input type="hidden" name="id_menu" value="<?php echo $data['id_menu']; ?>">
								<input type="hidden" name="kiosk" value="<?php echo $id_kiosk; ?>">
								</p>
								<button type="submit" class="w3-button w3-green" >Add To Cart</button>
								</form>
							</div>
						</div>
					</div>
					</center>
					<?php } ?>
				</div>
				

				<!-- End Page Container -->
			</div>




		</div>
		<!-- container end -->
		

		<footer class="w3-container w3-padding-1 w3-center" style="background: white;margin-top: 209px;">
			<p>&copy; 2023 FK KIOSK. All rights reserved.</p>
		</footer>


	</div>


	<script>
		var openInbox = document.getElementById("myBtn");
		openInbox.click();

		function w3_open() {
			document.getElementById("mySidebar").style.display = "block";
			document.getElementById("myOverlay").style.display = "block";
		}

		function w3_close() {
			document.getElementById("mySidebar").style.display = "none";
			document.getElementById("myOverlay").style.display = "none";
		}

		function myFunc(id) {
			var x = document.getElementById(id);
			if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-pale-red";
			} else {
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className =
					x.previousElementSibling.className.replace(" w3-red", "");
			}
		}
	</script>
<script type="text/javascript">

$(document).ready( function(){
$('#cartCount').load('../../config/checkcart.php');
refresh();
});
 
function refresh()
{
setTimeout( function() {
  $('#cartCount').load('../../config/checkcart.php');
  refresh();
}, 4000);
}

</script>
</body>

</html>