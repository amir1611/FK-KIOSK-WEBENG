<?PHP
session_start();

include("../config/database.php");
if (!verifyUser($con)) {
	header("Location: index.php");
	return false;
}
?>
<?PHP
$id_user	= $_SESSION["id_user"];
$act 		= (isset($_REQUEST['act'])) ? trim($_REQUEST['act']) : '';

$name 		= (isset($_POST['name'])) ? trim($_POST['name']) : '';
$email		= (isset($_POST['email'])) ? trim($_POST['email']) : '';
$phone		= (isset($_POST['phone'])) ? trim($_POST['phone']) : '';
$password	= (isset($_POST['password'])) ? trim($_POST['password']) : '';

$success = "";

if ($act == "edit") {
	$SQL_update = " 
	UPDATE
		`user`
	SET
		`name` = '$name',
		`email` = '$email',
		`phone` = '$phone',
		`password` = '$password'
	WHERE
		`id_user`='$id_user' 
		";

	$result = mysqli_query($con, $SQL_update);

	$success = "Successfully Update";
	//print "<script>self.location='a-profile.php';</script>";
}

$SQL_list = "SELECT * FROM `user` WHERE `id_user` = '$id_user' ";
$result = mysqli_query($con, $SQL_list);
$data	= mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="en">

<?php include 'head.php'; ?>
<title>Profile</title>

<body class="w3-biru">

	<!--- Toast Notification -->
	<?PHP
	if ($success) {
		Notify("success", $success, "profile.php");
	}
	?>
<?php include 'nav-1.php'; ?>



	<!-- Overlay effect when opening the side navigation on small screens -->
	<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="Close Sidemenu" id="myOverlay"></div>

	<!-- Page content -->
	<div class="w3-main" style="margin-left:250px;">



		<?php include 'nav-2.php'; ?>

		<div class="w3-padding-32"></div>

		<div class="w3-container">

			<!-- Page Container -->
			<div class="w3-container w3-white w3-content w3-card w3-padding-16" style="max-width:400px; border-radius:20px;">
				<!-- The Grid -->
				<div class="w3-row w3-padding">

					<form action="" method="post">
						<div class="w3-padding">
							<div style="text-align: center;">
								<b class="w3-large">Profile</b>
							</div>

							<hr>

							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Full Name <span style="color: red;">*</span></label>

								<input class="w3-input w3-border w3-round" type="text" name="name" value="<?PHP echo $data["name"]; ?>" required>
							</div>

							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Contact <span style="color: red;">*</span></label>

								<input class="w3-input w3-border w3-round" type="text" name="phone" value="<?PHP echo $data["phone"]; ?>" required>
							</div>

							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Email <span style="color: red;">*</span></label>

								<input class="w3-input w3-border w3-round" type="email" name="email" value="<?PHP echo $data["email"]; ?>" required>
							</div>

							<div class="w3-section">
								<label style="font-weight: bold; color: black;">Password <span style="color: red;">*</span></label>

								<input class="w3-input w3-border w3-round" type="password" name="password" value="<?PHP echo $data["password"]; ?>" required>
							</div>

							<hr class="w3-clear">
							<input type="hidden" name="act" value="edit">
							<div style="text-align: center;">
								<button type="submit" class="btn-grad w3-button w3-blue w3-margin-bottom w3-round">UPDATE</button>
							</div>

						</div>
					</form>


					<!-- End Grid -->
				</div>

				<!-- End Page Container -->
			</div>




		</div>
		<!-- container end -->


		<footer class="w3-container w3-padding-1 w3-center" style="background: white;margin-top: 209px;">
			<p>&copy; 2023 FK KIOSK. All rights reserved.</p>
		</footer>


	</div>


	<script>
		var openInbox = document.getElementById("myBtn");
		openInbox.click();

		function w3_open() {
			document.getElementById("mySidebar").style.display = "block";
			document.getElementById("myOverlay").style.display = "block";
		}

		function w3_close() {
			document.getElementById("mySidebar").style.display = "none";
			document.getElementById("myOverlay").style.display = "none";
		}

		function myFunc(id) {
			var x = document.getElementById(id);
			if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-pale-red";
			} else {
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className =
					x.previousElementSibling.className.replace(" w3-red", "");
			}
		}
	</script>

</body>

</html>