<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>In-store selling</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <center>
    <img src="images/logo.png"  width="50%" height="50%">
    </center>

    <h1>In-Store Selling</h1>

    <!-- Menu QR Code Scanner -->
    <div>
        <label for="qrCode">Scan QR Code:</label>
        <input type="text" id="qrCode" placeholder="Enter QR Code">
        <button onclick="addToCart()">Add to Cart</button>
    </div>

    <!-- Cart -->
    <div>
        <h2>Shopping Cart</h2>
        <ul id="cart">
            <!-- Cart items will be dynamically added here -->
        </ul>
        <p>Total Amount: $<span id="totalAmount">0.00</span></p>
        <button onclick="viewCart()">View Cart</button>
        <button onclick="cancelCart()">Cancel Cart</button>
        <p>Choose Payment Method:</p>
        <button onclick="checkout('online')">Online Payment</button>
        <button onclick="checkout('cash')">Cash Payment</button>
    </div>

    <!-- Points and Redemption -->
    <div>
        <h2>Points and Redemption</h2>
        <p>Points: <span id="userPoints">0</span></p>
        <button onclick="redeemPoints()">Redeem Points</button>
        <div id="redemptionSummaryContainer" style="display: none;">
            <p id="redemptionSummary"></p>
        </div>
    </div>

    <!-- Receipt -->
    <div id="receipt">
        <h2>Receipt</h2>
        <p>Date: <span id="receiptDate"></span></p>
        <ul id="receiptItems">
            <!-- Purchased items will be dynamically added here -->
        </ul>
        <p>Total Amount: <span id="receiptTotalAmount"></span></p>
        <button id="printReceiptButton" onclick="printReceipt()">Print Receipt</button>

    </div>

    <script src="script.js"></script>  
</body>

</html>
