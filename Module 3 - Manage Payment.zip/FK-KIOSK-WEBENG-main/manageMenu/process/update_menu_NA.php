<?PHP
include ("../../config/database.php");
$id=$_GET['id'];
echo $query =mysqli_query($con,"UPDATE `menu` SET `status`='2' WHERE `id_menu`='$id'");
mysqli_close($database);
header('location:../manage_menu.php');
?>