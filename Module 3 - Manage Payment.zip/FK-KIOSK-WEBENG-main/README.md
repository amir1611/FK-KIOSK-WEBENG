![FK-KIOSK MANAGEMENT SYSTEM](https://lh3.googleusercontent.com/u/0/drive-viewer/AK7aPaD2SoAVS6jLEdKNDbW7IyH9iCu5d4P0A4oVg4gqeu04ul4XGycxMm2Cbcp2xTb6j-KpeQJawyJL7LzbDefIxRy-rWFi9A=w1920-h911)
# FK-KIOSK MANAGEMENT SYSTEM
ONLINE KIOSK MANAGEMENT SYSTEM FOR FACULTY OF COMPUTING, UMPSA


## Deployment

To deploy this project run

```bash
  USER & VENDOR
  http://localhost:{REPLACE WITH YOUR PORT NUMBER}/manageAccount/user/index.php
```

```bash
  ADMIN
  http://localhost:{REPLACE WITH YOUR PORT NUMBER}/manageAccount/admin/admin.php
```



## Credentials

Login

```bash
  USER 

  Email: user@gmail.com
  Password: 1234
```

```bash
  Vendor

  Email: vendor@gmail.com
  Password: 1234
```


```bash
  Admin

  Username: admin
  Password: 1234
```
