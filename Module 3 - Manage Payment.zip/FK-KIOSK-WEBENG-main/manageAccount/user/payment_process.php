<?PHP
session_start();

include("../../config/database.php");
if (!verifyUser($con)) {
	header("Location: index.php");
	return false;
}
$id_user	= $_SESSION["id_user"];
$SQL_list = "SELECT * FROM `user` WHERE `id_user` = '$id_user' ";
$result = mysqli_query($con, $SQL_list);
$data	= mysqli_fetch_array($result);

$number = mt_rand(1000, 5000);


?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>FKKIOSK</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../../w3.css">
	<link href='https://fonts.googleapis.com/css?family=RobotoDraft' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link href="../../css/table.css" rel="stylesheet" />
	<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
	<script src="https://cdn.jsdelivr.net/jsbarcode/3.11.0/JsBarcode.all.min.js"></script>

	<style>
		a {
			text-decoration: none;
		}

		html,
		body,
		h1,
		h2,
		h3,
		h4,
		h5 {
			font-family: "RobotoDraft", "Roboto", sans-serif
		}

		.w3-bar-block .w3-bar-item {
			padding: 16px
		}

		.w3-biru {
			background-color: #f6f9ff;
		}

		         
		.btn-grad {
            background-image: linear-gradient(to right, #556270 0%, #FF6B6B  51%, #556270  100%);
            margin: 0px;
            padding: 15px 45px;
            text-align: center;
            text-transform: uppercase;
            transition: 0.5s;
            background-size: 200% auto;
            color: white;            
            box-shadow: 0 0 20px #eee;
            border-radius: 10px;
            display: block;
          }

          .btn-grad:hover {
            background-position: right center; /* change the direction of the change here */
            color: #fff;
            text-decoration: none;
          }
         

	</style>
<script>
        // Optionally, you can remove the onbeforeunload event when the page is unloaded (e.g., navigating away)
        window.onunload = function() {
            window.onbeforeunload = null;
        };
    </script>
</head>

<body class="w3-biru">

	<!-- Side Navigation -->
	<?php include 'nav-1.php'; ?>



	<!-- Overlay effect when opening the side navigation on small screens -->
	<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="Close Sidemenu" id="myOverlay"></div>

	<!-- Page content -->
	<div class="w3-main" style="margin-left:250px;">



		<div class="w3-white w3-bar w3-card ">


			<i class="fa fa-bars w3-buttonx w3-white w3-hide-large w3-xlarge w3-margin-left w3-margin-top" onclick="w3_open()"></i>


			<div class="w3-large w3-buttonx w3-bar-item w3-right w3-white w3-dropdown-hover">
				<button class="w3-button"><i class="fa fa-fw fa-user-circle"></i> User <i class="fa fa-fw fa-chevron-down w3-small"></i></button>
				<div class="w3-dropdown-content w3-bar-block w3-card-4" style="min-width: 54px;">
					<a href="profile.php" class="w3-bar-item w3-button"><i class="fa fa-fw fa-user-cog "></i> Profile</a>
					<a href="../../config/userlogout.php" class="w3-bar-item w3-button"><i class="fa fa-fw fa-sign-out-alt "></i> Logout</a>
				</div>
			</div>

		</div>

		<div class="w3-padding-16"></div>

			<?php
				require '../phpqrcode/qrlib.php';

				if ($_SERVER["REQUEST_METHOD"] == "POST") {
					$data = $number;
					$qrCodePath = "../qrcodes/qrcode.png";
					
					    // Customize options
					$options = [
						'errorCorrectionLevel' => QR_ECLEVEL_L,
						'margin' => 10, // Adjust the margin or border width
						// You can add more options here as needed
					];

					QRcode::png($data, $qrCodePath, QR_ECLEVEL_L, 10);

				}
				?>

		

		<div class="w3-container">

			<!-- Page Container -->
			<div class="w3-container w3-content w3-white w3-card w3-padding-16 w3-round" style="max-width:800px;">
			<center> <img src="<?php echo $qrCodePath;  ?>" style="border: 5px solid #000;" > </p>
			<h5> <b>Remark</b>: Please screenshot the QR or receipt order to show at the vendor kiosk cashier.</h5></center>
				<!-- The Grid -->
				<div class="w3-row w3-white w3-padding">
				
				<div class="table-responsive">
					<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="text-align: center;">
						<thead>
							<tr>
								<th>#</th>
								<th>Menu</th>
								<th>Quantity</th>
								<th>Total Price</th>
							</tr>
						</thead>
						
						
						

<?php
if (isset($_POST['selectedItems'])) {
    // Retrieve selected item IDs and quantity from the POST data
    $selectedItems = explode(',', $_POST['selectedItems']);

    // Process the selected item IDs and quantity
    $bil = 0; // Initialize $bil outside the loop
    $totalPrice = 0; // Initialize $totalPrice to store the sum of selected items' prices

    foreach ($selectedItems as $itemId) {
        $bil++; // Increment $bil for each selected item

        $SQL_list = "SELECT * FROM `cart` WHERE `id_cart` = '$itemId'";
        $result = mysqli_query($con, $SQL_list);

        while ($data = mysqli_fetch_array($result)) {
            ?>
            <tr>
                <td><?php echo $bil; ?></td>
                <td><?php
                    $menu = $data["id_menu"];
					$id_kiosk = $data["id_kiosk"];
                    $qrymm = "SELECT menu_name,price FROM `menu` WHERE `id_menu`='$menu'";
                    $resultmm = mysqli_query($con, $qrymm);
                    $rowmm = mysqli_fetch_array($resultmm, MYSQLI_ASSOC);
                    echo $id_kioskview = $rowmm['menu_name'];
                    $price = $rowmm['price'];
                    ?></td>
				<td><?php echo $qty=$data["qty"]; ?></td> <!-- Display quantity in the table -->
                <td>Rm <?php echo number_format((float)$final=$data["price"], 2, '.', ''); ?></td>
          
            </tr>
            <?php
            // Accumulate the price of the selected item to $totalPrice
            $totalPrice += (float)$final ;

            // Insert order details into the database, including quantity
            $insertder = "INSERT INTO `order`(`no_order`, `id_menu`, `id_kiosk`, `id_user`, `price`, `quantity`, `status`)VALUES ('$number', '$menu', '$id_kiosk', '$id_user', '$final', '$qty', '1')";
            $rel = mysqli_query($con, $insertder);
			if (!$rel) {
					die('Error in query: ' . mysqli_error($con));
				} else {
				}
					
        }
    }

    // Display the total price in the last row
    ?>
    <tr>
        <td colspan="3"><strong>Total Amount:</strong></td>
        <td>Rm<?php echo number_format($totalPrice, 2, '.', ''); ?></td>
    </tr>
    <?php
} else {
    // No selected items, show a message or redirect to another page
    echo '<h2>No items selected for payment.</h2>';
}
?>


					</table>	
					<!-- Proceed to Payment Button -->

				</div>


			</div>


				<!-- End Page Container -->
			</div>




		</div>
		<!-- container end -->


		<footer class="w3-container w3-padding-1 w3-center" style="background: white;margin-top: 308px;">
			<p>&copy; 2023 FK KIOSK. All rights reserved.</p>
		</footer>


	</div>
	<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
	<!--<script src="assets/demo/datatables-demo.js"></script>-->

	<script>
		$(document).ready(function() {


			$('#dataTable').DataTable({
				paging: true,

				searching: true
			});


		});
	</script>

	<script>
		var openInbox = document.getElementById("myBtn");
		openInbox.click();

		function w3_open() {
			document.getElementById("mySidebar").style.display = "block";
			document.getElementById("myOverlay").style.display = "block";
		}

		function w3_close() {
			document.getElementById("mySidebar").style.display = "none";
			document.getElementById("myOverlay").style.display = "none";
		}

		function myFunc(id) {
			var x = document.getElementById(id);
			if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-pale-red";
			} else {
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className =
					x.previousElementSibling.className.replace(" w3-red", "");
			}
		}
	</script>

</body>

</html>