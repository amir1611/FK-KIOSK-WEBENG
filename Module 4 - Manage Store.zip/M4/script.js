let cart = [];
        let totalAmount = 0;
        let userPoints = 0;

        function addToCart() {
            const qrCode = document.getElementById('qrCode').value;
            
            const menuItem = {
                name: 'Sample Item', 
                price: 5.99 
            };

            cart.push(menuItem);
            totalAmount += menuItem.price;

            document.getElementById('totalAmount').innerText = totalAmount.toFixed(2);
        }

        function viewCart() {
            const cartList = document.getElementById('cart');
            cartList.innerHTML = '';

            cart.forEach(item => {
                const listItem = document.createElement('li');
                listItem.innerText = `${item.name} - $${item.price.toFixed(2)}`;
                cartList.appendChild(listItem);
            });
        }

        function cancelCart() {
            cart = [];
            totalAmount = 0;
            document.getElementById('totalAmount').innerText = totalAmount.toFixed(2);
            viewCart();
        }

        function checkout(paymentMethod) {
            const receiptDate = new Date().toLocaleString();
            const receiptItems = document.getElementById('receiptItems');
            receiptItems.innerHTML = '';
        
            cart.forEach(item => {
                const listItem = document.createElement('li');
                listItem.innerText = `${item.name} - $${item.price.toFixed(2)}`;
                receiptItems.appendChild(listItem);
            });
        
            document.getElementById('receiptDate').innerText = receiptDate;
            document.getElementById('receiptTotalAmount').innerText = totalAmount.toFixed(2);
        
            document.getElementById('receipt').style.display = 'block';
        
            // Simulate payment based on the selected method
            if (paymentMethod === 'online') {
                
                alert('Redirecting to online payment gateway...');
            } else if (paymentMethod === 'cash') {
                
                alert('Cash payment received. Thank you!');
            }
        
            // Reset the cart after payment
            cart = [];
            totalAmount = 0;
            document.getElementById('totalAmount').innerText = totalAmount.toFixed(2);
            viewCart();
        }
        

        function redeemPoints() {
            
            const pointsToRedeem = 100;
            const discountAmount = 5;
        
            if (userPoints >= pointsToRedeem) {
                userPoints -= pointsToRedeem;
                totalAmount -= discountAmount;
        
                
                if (totalAmount < 0) {
                    totalAmount = 0;
                }
        
                document.getElementById('userPoints').innerText = userPoints;
                document.getElementById('totalAmount').innerText = totalAmount.toFixed(2);
            } else {
                alert('Insufficient points for redemption.');
            }
        }
        
        