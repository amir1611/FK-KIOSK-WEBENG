<?PHP
include ("../../../config/database.php");
$id_cart=$_GET['id_cart'];
echo $query =mysqli_query($con,"DELETE FROM `cart` WHERE `id_cart` ='$id_cart'");
header('location:../view_cart.php');
?>