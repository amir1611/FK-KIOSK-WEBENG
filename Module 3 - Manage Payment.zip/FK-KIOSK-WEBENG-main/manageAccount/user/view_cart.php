<?PHP
session_start();

include("../../config/database.php");
if (!verifyUser($con)) {
	header("Location: index.php");
	return false;
}
$id_user	= $_SESSION["id_user"];
$SQL_list = "SELECT * FROM `user` WHERE `id_user` = '$id_user' ";
$result = mysqli_query($con, $SQL_list);
$data	= mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>FKKIOSK</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../../w3.css">
	<link href='https://fonts.googleapis.com/css?family=RobotoDraft' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link href="../../css/table.css" rel="stylesheet" />
	<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
	<style>
		a {
			text-decoration: none;
		}

		html,
		body,
		h1,
		h2,
		h3,
		h4,
		h5 {
			font-family: "RobotoDraft", "Roboto", sans-serif
		}

		.w3-bar-block .w3-bar-item {
			padding: 16px
		}

		.w3-biru {
			background-color: #f6f9ff;
		}

		         
		.btn-grad {
            background-image: linear-gradient(to right, #556270 0%, #FF6B6B  51%, #556270  100%);
            margin: 0px;
            padding: 15px 45px;
            text-align: center;
            text-transform: uppercase;
            transition: 0.5s;
            background-size: 200% auto;
            color: white;            
            box-shadow: 0 0 20px #eee;
            border-radius: 10px;
            display: block;
          }

          .btn-grad:hover {
            background-position: right center; /* change the direction of the change here */
            color: #fff;
            text-decoration: none;
          }
         

	</style>
</head>

<body class="w3-biru">

	<!-- Side Navigation -->
	<?php include 'nav-1.php'; ?>



	<!-- Overlay effect when opening the side navigation on small screens -->
	<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="Close Sidemenu" id="myOverlay"></div>

	<!-- Page content -->
	<div class="w3-main" style="margin-left:250px;">



		<div class="w3-white w3-bar w3-card ">


			<i class="fa fa-bars w3-buttonx w3-white w3-hide-large w3-xlarge w3-margin-left w3-margin-top" onclick="w3_open()"></i>


			<div class="w3-large w3-buttonx w3-bar-item w3-right w3-white w3-dropdown-hover">
				<button class="w3-button"><i class="fa fa-fw fa-user-circle"></i> User <i class="fa fa-fw fa-chevron-down w3-small"></i></button>
				<div class="w3-dropdown-content w3-bar-block w3-card-4" style="min-width: 54px;">
					<a href="profile.php" class="w3-bar-item w3-button"><i class="fa fa-fw fa-user-cog "></i> Profile</a>
					<a href="../../config/userlogout.php" class="w3-bar-item w3-button"><i class="fa fa-fw fa-sign-out-alt "></i> Logout</a>
				</div>
			</div>

		</div>

		<div class="w3-padding-16"></div>



		<div class="w3-padding-16"></div>

		<div class="w3-container">

			<!-- Page Container -->
			<div class="w3-container w3-content w3-white w3-card w3-padding-16 w3-round" style="max-width:800px;">
				<!-- The Grid -->
				<div class="w3-row w3-white w3-padding">
				<div class="table-responsive">
					<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="text-align: center;">
						<thead>
							<tr>
								<th>#</th>
								<th><input type="checkbox" id="selectAllCheckbox"></th>
								<th>Menu</th>
								<th>Quantity</th>
								<th>Price</th>
								<th>Action</th>
							</tr>
						</thead>
						<?php
						$bil = 0;
						$SQL_list = "SELECT * FROM `cart` WHERE `id_user` = '$id_user'";
						$result = mysqli_query($con, $SQL_list);
						while ($data = mysqli_fetch_array($result)) {
							$bil++;
						?>
							<tr>
								<td><?php echo $bil; ?></td>
								<td><input type="checkbox" name="selectedItems[]" value="<?php echo $data['id_cart']; ?>"></td>
								<td><?php
									$menu = $data["id_menu"];
									$qrymm = "SELECT menu_name FROM `menu` WHERE `id_menu`='$menu'";
									$resultmm = mysqli_query($con, $qrymm);
									$rowmm = mysqli_fetch_array($resultmm, MYSQLI_ASSOC);
									echo $id_kioskview = $rowmm['menu_name'];
									?></td>
								<td><?php echo $data["qty"] ?></td>
								<td><?php echo number_format((float)$data["price"], 2, '.', ''); ?></td>
								
								<td>
								
								<?php $del_cart = "process/del_cart.php?id_cart=" . $data['id_cart'] . "&iduser=" . $data['id_user']; ?>

								<a href="<?php echo $del_cart; ?>" class="w3-button w3-red" style="border-radius: 20px;"><i class="fas fa-times"></i> Delete</a>
								
								
								
								
								
								</td>
							</tr>
						<?php } ?>
					</table>

					<!-- Proceed to Payment Button -->
					<button class="w3-button w3-green" onclick="proceedToPayment()">Proceed to Payment</button>
				</div>

<script>
function proceedToPayment() {
    var confirmation = confirm('Are you sure you want to proceed to payment?');
    if (confirmation) {
        // Get all selected items
        var selectedItems = [];

        var checkboxes = document.getElementsByName('selectedItems[]');

        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].checked) {
                selectedItems.push(checkboxes[i].value);
            }
        }

        // Check if any item is selected
        if (selectedItems.length > 0) {
            // Create a form element
            var form = document.createElement('form');
            form.method = 'POST';
            form.action = 'payment_process.php';

            // Create hidden input for selectedItems
            var inputSelectedItems = document.createElement('input');
            inputSelectedItems.type = 'hidden';
            inputSelectedItems.name = 'selectedItems';
            inputSelectedItems.value = selectedItems.join(',');
            form.appendChild(inputSelectedItems);
			
			console.log(form.outerHTML);

            // Append the form to the document body
            document.body.appendChild(form);

            // Submit the form
            form.submit();
        } else {
            // No items selected, show an alert or perform other actions
            alert('Please select at least one item to proceed with payment.');
        }
    } else {
        // User clicked "Cancel"
        alert('Payment cancelled');
        // Add any additional logic for the cancel action
    }
}
</script>










			</div>


				<!-- End Page Container -->
			</div>




		</div>
		<!-- container end -->


		<footer class="w3-container w3-padding-1 w3-center" style="background: white;margin-top: 308px;">
			<p>&copy; 2023 FK KIOSK. All rights reserved.</p>
		</footer>


	</div>
	<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
	<!--<script src="assets/demo/datatables-demo.js"></script>-->

	<script>
		$(document).ready(function() {


			$('#dataTable').DataTable({
				paging: true,

				searching: true
			});


		});
	</script>

	<script>
		var openInbox = document.getElementById("myBtn");
		openInbox.click();

		function w3_open() {
			document.getElementById("mySidebar").style.display = "block";
			document.getElementById("myOverlay").style.display = "block";
		}

		function w3_close() {
			document.getElementById("mySidebar").style.display = "none";
			document.getElementById("myOverlay").style.display = "none";
		}

function myFunc(id) {
    var x = document.getElementById(id);

    // Check if x exists before proceeding
    if (x) {
        if (x.className.indexOf("w3-show") === -1) {
            x.className += " w3-show";

            // Check if the previous sibling exists before manipulating its className
            if (x.previousElementSibling) {
                x.previousElementSibling.className += " w3-pale-red";
            }
        } else {
            x.className = x.className.replace(" w3-show", "");

            // Check if the previous sibling exists before manipulating its className
            if (x.previousElementSibling) {
                x.previousElementSibling.className =
                    x.previousElementSibling.className.replace(" w3-pale-red", "");
            }
        }
    } else {
        console.error('Element not found or is null');
    }
}
	</script>

</body>

</html>