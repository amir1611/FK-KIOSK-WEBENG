<?php
session_start();

include("database.php");
if (!verifyUser($con)) {
    // Handle unauthorized access if needed
    echo "Unauthorized access";
    return;
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id_user = $_SESSION["id_user"];

    // Retrieve cart count from the database
    $SQL_count = "SELECT COUNT(*) AS cart_count FROM `cart` WHERE `id_user` = '$id_user'";
    $result = mysqli_query($con, $SQL_count);
    
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        echo $row['cart_count'];
    } else {
        echo "Error retrieving cart count";
    }
} else {
    echo "Invalid request method";
}
?>
