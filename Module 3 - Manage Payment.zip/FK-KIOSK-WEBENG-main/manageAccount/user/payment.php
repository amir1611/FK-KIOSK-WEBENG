<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Payment Page</title>
</head>
<script src="https://cdn.jsdelivr.net/jsbarcode/3.11.0/JsBarcode.all.min.js"></script>
<body>

<?php
// Check if selectedItems parameter is set in the URL
if (isset($_POST['selectedItems'])) {
    // Retrieve selected item IDs from the URL parameter
    $selectedItems = explode(',', $_POST['selectedItems']);

    // Process the selected item IDs (you can perform database operations, calculations, etc.)
    echo '<h2>Selected Item IDs:</h2>';
    echo '<ul>';
    foreach ($selectedItems as $itemId) {
        echo '<li>' . htmlspecialchars($itemId) . '</li>';
        // Add your processing logic here
    }
    echo '</ul>';
} else {
    // No selected items, show a message or redirect to another page
    echo '<h2>No items selected for payment.</h2>';
}
?>
<div id="barcodeDisplay"></div>
    <!-- Button to generate barcode -->
    <button onclick="generateBarcode()">Generate Barcode</button>

    <script>
        function generateBarcode() {
            // Get the Itemid from the previous page (you may need to adjust this based on your setup)
            var itemId = <?php echo json_encode($_POST['selectedItems']); ?>;

            // Generate the barcode
            JsBarcode("#barcodeDisplay", itemId, {
                format: "CODE128",  // You can choose other barcode formats as needed
                displayValue: true   // Display the value below the barcode
            });
        }
    </script>
<!-- Your payment page content goes here -->

</body>
</html>
