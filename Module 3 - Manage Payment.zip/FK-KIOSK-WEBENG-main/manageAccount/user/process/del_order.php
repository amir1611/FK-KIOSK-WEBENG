<?PHP
include ("../../../config/database.php");
$id_order=$_GET['id_order'];
echo $query =mysqli_query($con,"DELETE FROM `order` WHERE `id_order` ='$id_order'");
header('location:../menu_history.php');
?>