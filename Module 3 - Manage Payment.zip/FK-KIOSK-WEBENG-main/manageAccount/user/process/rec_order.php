<?PHP
include ("../../../config/database.php");
$id_order=$_GET['id_order'];
$query =mysqli_query($con,"UPDATE `order` SET `status`='2' WHERE `id_order` ='$id_order'");
header('location:../menu_history.php');
?>